# Приложение по конкретной игре

- `GAME_ID`:
- `GAME_TITLE`:
- `RO_SOURCE_ID` (Drive folder / artifact URL):
- `NEW_WORKSPACE_ID` (отдельная, согласованная директория):
- `OWNER / SINGLE_PROMOTION_WRITER`:
- `SUPPORTED_SCOPE` (Core, languages, edition, packs):
- `EXPLICITLY_EXCLUDED_SCOPE`:
- `SOURCE_STANDARDS` (например, BoardGame_KB_Standard_v2_0):
- `PRIOR_CANONICAL` (ID, SHA, CONTROL/LATEST):
- `CONFLICTING_CHECKPOINTS`:
- `AVAILABLE_PRINTED_ASSETS`:
- `ALLOWED_OSINT_SOURCES`:
- `ACCEPTANCE_GATES`:
- `KNOWN_OPEN_QUESTIONS`:
- `FIRST_PILOT_OBJECTS`:
- `GOOGLE_DRIVE_WRITE_AND_READBACK_CONSTRAINTS`:

Без заполненного адаптера не запускать массовый перенос. Если поле неизвестно, явно пометить `UNKNOWN`; не подменять догадкой.
