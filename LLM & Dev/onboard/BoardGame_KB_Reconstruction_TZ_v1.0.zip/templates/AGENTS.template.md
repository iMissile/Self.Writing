# AGENTS.md — контракт работы агента с `<GAME>` KB

## За первые 60 секунд
1. Читай `KB_MANIFEST.json` → `README.md` → `STATUS.md` → `SCOPE.md` → `HOW_TO_SEARCH.md`.
2. Прочти `CONTROL.json` и `LATEST` **из канонической директории**, затем проверь hash/id по `13_releases`.
3. Сохраняй различия между `SOURCE_COVERED`, `PRINTED_VERIFIED`, `RULE_VERIFIED`, `MECHANICS_VERIFIED`, `EXECUTABLE_TESTED`, `AGENT_VALIDATED`.

## Что можно делать
- Искать по stable ID, aliases, локализации, продукту, редакции, датам и источникам.
- Формировать проверяемые запросы к machine-readable слоям и Obsidian.
- Собирать изменения в отдельно созданном WIP с parent checkpoint, ledger и evidence.
- Исследовать новые источники **в пределах SCOPE**; принимать только адресуемые подтверждения.
- Фиксировать отрицательные результаты, конкурирующие трактовки и blocked assets.

## Чего нельзя делать
- Изменять исходную RO БЗ или любой immutable checkpoint.
- Объявлять YAML, OCR или результаты LLM доказательством `VERIFIED`.
- Перезаписывать PRINTED данными EFFECTIVE или делать обратное.
- Считать зелёный pytest доказательством правильности правил.
- Переучитывать уже принятые источники и заново выполнять закрытый OSINT без причины.
- Менять `CONTROL.json`/`LATEST` до QA, remote readback, parent recheck и single-writer publication.
- Расширять круг продуктов/паков без явной команды владельца.

## Цикл
`read canonical → pick linked WP → PREQA save → migrate facts + evidence → semantic QA → regression → publish immutable STAGED → remote readback → safe PROMOTION or HANDOFF`.

## Ответ по каждому факту
Верни `entity_id`, `field`, `value`, `status`, `source_id`, `locator`, `as_of`, `dataset_release`.
Если доказательства нет — отвечай `UNKNOWN` с причиной и открытым вопросом.

## При прерывании
Начни с `HANDOFF.md`, `RUN_STATE.json`, проверенного `LATEST` и `MIGRATION_LEDGER`; не продолжай из непроверенной локальной WIP-копии без сверки.
