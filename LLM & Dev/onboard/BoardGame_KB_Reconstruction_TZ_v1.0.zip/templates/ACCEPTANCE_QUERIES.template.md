# Acceptance queries — образцы с ожидаемыми ответами

Для каждого запроса вести `query_id`, `scope`, `index`, `exact_query`, `expected_entity_ids`, `expected_fields`, `expected_provenance`, `expected_status`, `baseline_release`, `actual`, `pass/fail`, `qa_receipt`.

| Query ID | Вопрос | Что должно проверяться |
|---|---|---|
| Q01 | Какие карты входят в Core Set? | product/BOM/card printing crosswalk, знаменатель |
| Q02 | Где карточка с номером N на RU? | ID, aliases, locale, printing |
| Q03 | Что напечатано на карте X? | значение + конкретная печать + ROI + PRINTED статус |
| Q04 | Какая errata меняла карту X? | supersedes/effective temporal |
| Q05 | Как звучало правило на дату D? | as-of со срезом edition/effective |
| Q06 | Каким источником подтверждено поле cost? | field-level provenance/locator |
| Q07 | Какие источники противоречат друг другу? | CONFLICTED claims без автоматического слияния |
| Q08 | Какие проверки карты не сделаны? | unknown/blocked явным списком |
| Q09 | Какой полный состав продукта? | BOM, component quantity, источник |
| Q10 | Какие карты реализуют механику X? | граф + корректный scope |
| Q11 | Какой тест проверяет правило Y? | rule/test crosswalk и статус теста |
| Q12 | Можно ли запускать self-play? | gates с явным отсутствием ложного PASS |
| Q13 | Какие исследования дали нулевой результат? | research log negative results |
| Q14 | Где лежат оригиналы сканов? | external asset ID, SHA, доступность |
| Q15 | Что было отброшено как мусор? | file-ledger disposition+reason |
| Q16 | Чем отличается EN и RU печать? | printings/localization mapping и provenance |
| Q17 | Какие продукты ещё не исследованы? | scope vs known-catalog vs authorized expansion |
| Q18 | Что изменилось между R0003 и R0004? | semantic diff, coverage delta, changelog |
| Q19 | Как восстановить последний PROMOTED? | clean restore + hashes + source links |
| Q20 | Что агент ответит на несуществующую карту? | корректное UNKNOWN, отсутствие галлюцинаций |

**Требование:** заполнить конкретные ответы по выбранной игре после пилота; абстрактные шаблоны не считаются выполненными тестами.
