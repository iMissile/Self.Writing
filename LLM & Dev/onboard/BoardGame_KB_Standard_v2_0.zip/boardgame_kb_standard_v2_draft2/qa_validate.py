#!/usr/bin/env python3
"""Validate synthetic examples only; this is NOT a production temporal resolver.

Supported query subset: exact days, literal scope equality, accepted/withdrawn
records and explicit supersedes. Unknown/unsupported time bounds and competing
accepted values fail explicitly. No network, canonical data writes or game engine.
"""
from __future__ import annotations

import copy
import hashlib
import json
import sys
import unittest
from datetime import date, datetime
from pathlib import Path
from typing import Any

try:
    from jsonschema import Draft202012Validator, FormatChecker, ValidationError
except ImportError as exc:
    raise SystemExit('Install the Python package jsonschema before running this example.') from exc

ROOT = Path(__file__).resolve().parent
Row = dict[str, Any]


def load_jsonl(path: Path) -> list[Row]:
    result = []
    for line_no, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if line.strip():
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f'{path.name}:{line_no}: invalid JSON') from exc
    return result


SCHEMA = json.loads((ROOT/'entity_revision.schema.json').read_text(encoding='utf-8'))
VALIDATOR = Draft202012Validator(SCHEMA, format_checker=FormatChecker())
ROWS = load_jsonl(ROOT/'examples/revision_history_example.jsonl')
SOURCES = {r['source_id']: r for r in load_jsonl(ROOT/'examples/sources_example.jsonl')}
SCOPES = {r['scope_id']: r for r in load_jsonl(ROOT/'examples/scopes_example.jsonl')}


def timestamp(text: str) -> datetime:
    dt = datetime.fromisoformat(text.replace('Z', '+00:00'))
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError('Timezone is required')
    return dt


class UnknownTime(ValueError):
    """The demonstration cannot establish temporal applicability."""


class ConflictingValues(ValueError):
    """Explicit resolution is needed; latest timestamp is not a truth rule."""


def exact_day(bound: Row) -> date | None:
    if bound['state'] == 'unbounded':
        return None
    if bound['state'] != 'known' or bound['at']['precision'] != 'day':
        raise UnknownTime('Unknown/uncertain/non-day boundary requires an explicit full resolver')
    return date.fromisoformat(bound['at']['value'])


def check_corpus(rows: list[Row]) -> None:
    """A limited integrity check for these fully local synthetic fixtures."""
    if not rows or len({r['dataset_id'] for r in rows}) != 1:
        raise ValueError('Expected one nonempty logical dataset')
    by_id = {r['record_revision_id']: r for r in rows}
    if len(by_id) != len(rows):
        raise ValueError('Duplicate record revision ID')
    domain_ids = {r['domain_revision_id'] for r in rows if r['domain_revision_id'] is not None}
    for row in rows:
        VALIDATOR.validate(row)
        if not row['is_synthetic'] or row['authority'] != 'synthetic':
            raise ValueError('This QA corpus must remain synthetic')
        if row['scope_id'] not in SCOPES:
            raise ValueError('Orphan scope')
        for ref in row['source_refs']:
            source = SOURCES[ref['source_id']]
            raw = (ROOT/'examples'/source['path']).read_bytes()
            if hashlib.sha256(raw).hexdigest() != ref['sha256'] or ref['sha256'] != source['sha256']:
                raise ValueError('Source hash mismatch')
        for rid in row['supersedes_record_revision_ids']:
            old = by_id[rid]
            for key in ('dataset_id', 'game_id', 'entity_id', 'field_path', 'layer', 'scope_id'):
                if row[key] != old[key]:
                    raise ValueError('Cross-target supersedes requires a separate migration decision')
            if timestamp(row['recorded_at']) <= timestamp(old['recorded_at']):
                raise ValueError('This fixture requires strictly later superseding revisions')
            if row['change_kind'] == 'record_correction' and row['domain_revision_id'] != old['domain_revision_id']:
                raise ValueError('Record correction must not invent a new domain revision')
        for did in row['revises_domain_revision_ids']:
            if did not in domain_ids or did == row['domain_revision_id']:
                raise ValueError('Invalid domain revision predecessor')
        validity = row['valid_time']
        if validity['kind'] == 'interval':
            try:
                lo, hi = exact_day(validity['start']), exact_day(validity['end'])
            except UnknownTime:
                pass  # An unknown bound is representable, but cannot produce a strict temporal answer.
            else:
                if lo is not None and hi is not None and lo >= hi:
                    raise ValueError('Empty/reversed valid interval')


def known_records(rows: list[Row], known_at: str) -> list[Row]:
    visible = [r for r in rows if timestamp(r['recorded_at']) <= timestamp(known_at)]
    superseded = {
        rid for r in visible if r['status'] in ('accepted', 'withdrawn')
        for rid in r['supersedes_record_revision_ids']
    }
    return [r for r in visible if r['status'] == 'accepted' and r['record_revision_id'] not in superseded]


def select(rows: list[Row], *, entity: str, field: str, layer: str,
           scope: str, known_at: str, valid_at: str | None = None) -> Row:
    candidates = [r for r in known_records(rows, known_at)
                  if (r['entity_id'], r['field_path'], r['layer'], r['scope_id']) == (entity, field, layer, scope)]
    applicable = []
    for row in candidates:
        validity = row['valid_time']
        if validity['kind'] == 'unknown':
            raise UnknownTime('Effective period is unknown, not empty or unbounded')
        if validity['kind'] == 'not_applicable':
            if layer != 'printed':
                raise UnknownTime('This demonstration supports not_applicable only for fixed printed readings')
            applicable.append(row)
            continue
        if valid_at is None:
            raise ValueError('valid_at is required for an interval query')
        day = date.fromisoformat(valid_at)
        start, end = exact_day(validity['start']), exact_day(validity['end'])
        if (start is None or start <= day) and (end is None or day < end):
            applicable.append(row)
    if len(applicable) > 1:
        raise ConflictingValues('Multiple accepted applicable records; explicit resolution required')
    if not applicable:
        raise LookupError('No accepted applicable value; do not substitute zero/empty/default')
    return applicable[0]


def rule(rows: list[Row] = ROWS, *, known: str = '2026-10-20T11:00:00Z',
         valid: str = '2018-07-01', entity: str = 'EX-RULE-A',
         scope: str = 'EX-SCOPE-EN-STANDARD') -> Row:
    return select(rows, entity=entity, field='text', layer='effective', scope=scope,
                  known_at=known, valid_at=valid)


def printed(known: str) -> Row:
    return select(ROWS, entity='EX-CARD-A', field='cost', layer='printed',
                  scope='EX-SCOPE-EN-PRINT-A', known_at=known)


def merge_for_demo(existing: list[Row], incoming: list[Row]) -> list[Row]:
    """Illustrate ID idempotency without writing to a real dataset."""
    index = {r['record_revision_id']: copy.deepcopy(r) for r in existing}
    for row in incoming:
        rid = row['record_revision_id']
        if rid in index and index[rid] != row:
            raise ValueError('Immutable record revision ID reused for different payload')
        index[rid] = copy.deepcopy(row)
    return list(index.values())


class RevisionExamples(unittest.TestCase):
    def test_schema_and_all_eight_rows(self):
        Draft202012Validator.check_schema(SCHEMA)
        self.assertEqual(len(ROWS), 8)
        for row in ROWS:
            VALIDATOR.validate(row)

    def test_fixture_hashes_links_and_supersedes(self):
        check_corpus(ROWS)

    def test_one_dataset_new_pack_no_core_clone(self):
        self.assertEqual({r['dataset_id'] for r in ROWS}, {'EX-DATASET-ONE'})
        self.assertEqual({r['entity_id'] for r in ROWS if r['entity_kind'] == 'card'}, {'EX-CARD-A', 'EX-CARD-B'})
        self.assertEqual(sum(r['entity_id'] == 'EX-CARD-B' for r in ROWS), 1)

    def test_old_knowledge_before_late_errata(self):
        self.assertEqual(rule(known='2026-10-05T00:00:00Z')['value'], 'Взять 1 карту')

    def test_new_knowledge_reconstructs_same_past_differently(self):
        self.assertEqual(rule()['value'], 'Взять 2 карты')

    def test_original_valid_period_remains(self):
        self.assertEqual(rule(valid='2018-05-31')['value'], 'Взять 1 карту')

    def test_half_open_boundary(self):
        self.assertEqual(rule(valid='2018-06-01')['record_revision_id'], 'EX-REV-004')

    def test_errata_does_not_rewrite_printed(self):
        self.assertEqual(printed('2026-10-15T00:00:00Z')['value'], 2)
        self.assertEqual(ROWS[0]['value'], 2)

    def test_transcription_correction_same_identity_and_domain(self):
        old, new = printed('2026-10-05T00:00:00Z'), printed('2026-10-20T11:00:00Z')
        self.assertEqual((old['value'], new['value']), (2, 3))
        self.assertEqual(old['entity_id'], new['entity_id'])
        self.assertEqual(old['domain_revision_id'], new['domain_revision_id'])
        self.assertEqual(old['value'], 2)  # Querying new knowledge did not mutate the old record.

    def test_unknown_valid_time_is_not_recorded_time(self):
        with self.assertRaises(UnknownTime):
            rule(entity='EX-RULE-U')

    def test_parallel_scope_does_not_replace_other_locale(self):
        self.assertEqual(rule()['value'], 'Взять 2 карты')
        self.assertEqual(rule(scope='EX-SCOPE-RU-ALT')['value'], 'Взять 3 карты')

    def test_later_conflict_not_resolved_by_latest(self):
        row = copy.deepcopy(ROWS[3])
        row.update(record_revision_id='EX-CONFLICT', domain_revision_id='EX-OTHER-DOMAIN',
                   recorded_at='2026-10-20T10:30:00Z', value='Взять 99 карт')
        with self.assertRaises(ConflictingValues):
            rule(ROWS + [row])

    def test_candidates_and_rejected_do_not_displace_accepted(self):
        for status in ('candidate', 'rejected'):
            with self.subTest(status=status):
                row = copy.deepcopy(ROWS[3])
                row.update(record_revision_id='EX-UNACCEPTED', recorded_at='2026-10-20T10:30:00Z',
                           status=status, value='Взять 99 карт', change_kind='record_correction',
                           supersedes_record_revision_ids=['EX-REV-004'], revises_domain_revision_ids=[])
                self.assertEqual(rule(ROWS + [row])['value'], 'Взять 2 карты')

    def test_wrong_domain_for_record_correction_rejected(self):
        rows = copy.deepcopy(ROWS)
        rows[-1]['domain_revision_id'] = 'EX-INVENTED-PRINTING'
        with self.assertRaises(ValueError):
            check_corpus(rows)

    def test_timezone_required_by_schema(self):
        row = copy.deepcopy(ROWS[0])
        row['recorded_at'] = '2026-10-01T10:00:00'
        with self.assertRaises(ValidationError):
            VALIDATOR.validate(row)

    def test_unknown_boundary_not_infinite(self):
        rows = copy.deepcopy(ROWS)
        rows[3]['valid_time']['end'] = {'state': 'unknown'}
        with self.assertRaises(UnknownTime):
            rule(rows)

    def test_repeat_merge_idempotent_and_payload_immutable(self):
        merged = merge_for_demo(ROWS, ROWS)
        self.assertEqual(merged, ROWS)
        bad = copy.deepcopy(ROWS[0]); bad['value'] = 999
        with self.assertRaises(ValueError):
            merge_for_demo(ROWS, [bad])

    def test_reversed_valid_interval_rejected(self):
        rows = copy.deepcopy(ROWS)
        rows[2]['valid_time']['end']['at']['value'] = '2017-01-01'
        with self.assertRaises(ValueError):
            check_corpus(rows)

    def test_orphan_or_cross_entity_supersedes_rejected(self):
        rows = copy.deepcopy(ROWS)
        rows[-1]['supersedes_record_revision_ids'] = ['EX-REV-005']
        with self.assertRaises(ValueError):
            check_corpus(rows)

    def test_supersedes_cycle_rejected(self):
        rows = copy.deepcopy(ROWS)
        rows[0]['supersedes_record_revision_ids'] = ['EX-REV-008']
        with self.assertRaises(ValueError):
            check_corpus(rows)

    def test_invalid_unknown_payload_not_silent(self):
        row = copy.deepcopy(ROWS[5])
        row['valid_time']['start'] = {'state': 'unbounded'}
        with self.assertRaises(ValidationError):
            VALIDATOR.validate(row)

    def test_legacy_example_shapes_only(self):
        p = ROOT/'legacy_draft1_examples'
        for schema_file, data_file in [('release_event.schema.json', 'release_events_example.jsonl'),
                                       ('scope_manifest.schema.json', 'scope_manifest_example.json')]:
            schema = json.loads((p/schema_file).read_text(encoding='utf-8'))
            Draft202012Validator.check_schema(schema)
            validator = Draft202012Validator(schema, format_checker=FormatChecker())
            data = load_jsonl(p/data_file) if data_file.endswith('.jsonl') else [json.loads((p/data_file).read_text(encoding='utf-8'))]
            for row in data:
                validator.validate(row)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(RevisionExamples)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {'tests_run': result.testsRun, 'failures': len(result.failures),
               'errors': len(result.errors), 'synthetic_only': True,
               'production_resolver_verified': False, 'canonical_data_changed': False}
    print(json.dumps(summary, ensure_ascii=False))
    sys.exit(0 if result.wasSuccessful() else 1)
