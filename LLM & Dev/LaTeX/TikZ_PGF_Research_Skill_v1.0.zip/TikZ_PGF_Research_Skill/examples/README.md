# Gallery / examples — компилируемые фигуры

Все примеры оригинальные. На графиках с данными используется **только синтетика**, никаких реальных результатов исследования они не утверждают. Иллюстрация карты `assets/synthetic_card.png` тоже создана специально для демонстрации.

Запуск из корня:

```bash
python scripts/build_examples.py
```

Результат: PDF + PNG для каждого примера, JSON с логами и проверками, `build/gallery.pdf` (после успешного вывода).

| Файл | Что показывает | Engine |
|---|---|---|
| 01_state_machine.tex | формальные события/запреты | XeLaTeX |
| 02_hidden_states.tex | неразличимость скрытых миров | XeLaTeX |
| 03_game_tree.tex | игровое дерево, Forest | XeLaTeX |
| 04_pipeline_dag.tex | DAG данных и QA | XeLaTeX |
| 05_uncertainty_plot.tex | PGFPlots, диапазон и кривая на синтетических данных | XeLaTeX |
| 06_surface.tex | PGFPlots поверхность функции потерь | XeLaTeX |
| 07_geometry.tex | геометрия `calc`/`angles`/`quotes` | XeLaTeX |
| 08_image_roi.tex | нормализованные аннотации поверх синтетического изображения | XeLaTeX |
| 09_matrix.tex | блочная матрица | XeLaTeX |
| 10_commutative.tex | математическая коммутативная диаграмма | XeLaTeX |
| 11_timeline.tex | план/факты на timeline | XeLaTeX |
| 12_composite.tex | составная двухпанельная схема | XeLaTeX |
| 13_graphdrawing_lua.tex | авто-layout с LuaTeX | LuaLaTeX |
| 14_circuit.tex | RC цепь с CircuiTikZ | XeLaTeX |
| 15_bayes_update.tex | предсказание + байесовское обновление | XeLaTeX |

**Не переносить** имена/даты/числа из этих примеров в исследовательские статьи как будто это реальные результаты.
