#!/usr/bin/env python3
"""Compile independent TikZ examples with safety, logs, previews and JSON QA.

Usage: python scripts/build_examples.py [--jobs 3] [--only 01_state_machine.tex]
Runs in any folder, uses repo root for absolute paths. Shell escape disabled.
"""
import argparse, concurrent.futures, hashlib, json, shutil, subprocess, time
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
EX=ROOT/'examples'; OUT=ROOT/'build'; PREV=OUT/'previews'; LOGS=OUT/'logs'

def build(tex: Path):
    name=tex.stem
    engine='lualatex' if 'graphdrawing_lua' in name else 'xelatex'
    dest=OUT/name
    dest.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    cmd=[engine,'-no-shell-escape','-halt-on-error','-file-line-error','-interaction=nonstopmode',
         f'-output-directory={dest}', tex.name]
    try:
        result=subprocess.run(cmd,cwd=EX,capture_output=True,text=True,timeout=100)
        code=result.returncode
        stdout=(result.stdout or '')[-4000:] + (result.stderr or '')[-1000:]
    except subprocess.TimeoutExpired as exc:
        code=124; stdout='TIMEOUT: '+str(exc)
    except OSError as exc:
        code=127; stdout='OSERROR: '+str(exc)
    (LOGS/f'{name}.logtail.txt').write_text(stdout,encoding='utf-8')
    pdf=dest/(name+'.pdf'); png=PREV/(name+'.png')
    good=code==0 and pdf.is_file() and pdf.stat().st_size>1000
    pages=None; width_pt=height_pt=None; content_check=None
    if good:
        try:
            import fitz
            doc=fitz.open(str(pdf));pages=doc.page_count
            if pages != 1: good=False
            else:
                rect=doc[0].rect;width_pt=round(rect.width,2);height_pt=round(rect.height,2)
                if rect.width<=10 or rect.height<=10 or rect.width>2500 or rect.height>2000: good=False
            doc.close()
        except ImportError:pass
    if good:
        try:
            try:
                import fitz
                with fitz.open(str(pdf)) as doc:
                    page=doc[0]
                    pix=page.get_pixmap(matrix=fitz.Matrix(1.65,1.65),alpha=False)
                    pix.save(str(png))
            except ImportError:
                subprocess.run(['pdftoppm','-f','1','-singlefile','-png','-r','120',str(pdf),str(png.with_suffix(''))],
                               check=True,timeout=30,capture_output=True)
            from PIL import Image, ImageChops
            im=Image.open(png).convert('RGB')
            diff=ImageChops.difference(im,Image.new('RGB',im.size,'white'))
            content_check=diff.getbbox() is not None
            good=good and content_check
        except Exception as exc:
            good=False;stdout+='\nRENDER ERROR: '+str(exc)
    return {'name':name,'engine':engine,'success':bool(good),'exit_code':code,
            'seconds':round(time.monotonic()-start,2),'pages':pages,
            'size_pt':[width_pt,height_pt], 'non_blank':content_check,
            'tex_sha256':hashlib.sha256(tex.read_bytes()).hexdigest(),
            'pdf':str(pdf.relative_to(ROOT)) if pdf.is_file() else None,
            'preview':str(png.relative_to(ROOT)) if png.is_file() else None,
            'log':str((LOGS/f'{name}.logtail.txt').relative_to(ROOT))}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--jobs',type=int,default=3)
    ap.add_argument('--only',default='')
    args=ap.parse_args()
    OUT.mkdir(parents=True,exist_ok=True);PREV.mkdir(parents=True,exist_ok=True);LOGS.mkdir(parents=True,exist_ok=True)
    texs=sorted(EX.glob('*.tex'))
    if args.only: texs=[p for p in texs if p.name==args.only or p.stem==args.only]
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,args.jobs)) as pool:
        results=sorted(pool.map(build,texs),key=lambda x:x['name'])
    status=all(r['success'] for r in results)
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'all_ok':status,
            'passed':sum(r['success'] for r in results),'total':len(results),'results':results}
    (OUT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(f"Compiled {report['passed']}/{report['total']} | all_ok={status}")
    for x in results:
        print('PASS' if x['success'] else 'FAIL',x['name'],x['engine'],x['seconds'],'s',x['size_pt'])
    if results and status and not args.only:
        inputs=[str(OUT/r['name']/(r['name']+'.pdf')) for r in results]
        try:
            import fitz
            gallery=fitz.open()
            for pdf in inputs:
                with fitz.open(pdf) as source:gallery.insert_pdf(source)
            gallery.save(str(OUT/'gallery.pdf'),garbage=4,deflate=True)
            gallery.close()
            print('Gallery:',OUT/'gallery.pdf')
        except ImportError:
            if shutil.which('pdfunite'):
                subprocess.run(['pdfunite',*inputs,str(OUT/'gallery.pdf')],check=True)
                print('Gallery:',OUT/'gallery.pdf')
    raise SystemExit(0 if status else 1)

if __name__=='__main__':main()
