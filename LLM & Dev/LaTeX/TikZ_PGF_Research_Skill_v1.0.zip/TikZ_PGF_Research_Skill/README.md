# TikZ/PGF Scientific Graphics — agent skill v1.0

Переиспользуемый русскоязычный скилл по профессиональному построению математических, алгоритмических, инженерных и научных рисунков в TikZ/PGF и его экосистеме.

**Основная инструкция:** [`SKILL.md`](SKILL.md). Дополнительные руководства лежат в `references/`, работающие примеры — в `examples/`, стандарты исходников — в `templates/`, проверка — `scripts/build_examples.py`.

## Для человека / агента

1. Прочитай `SKILL.md` (в особенности §0–2, §14–16).
2. Выбери тип фигуры по маршрутизатору.
3. Для новых/сомнительных keys проверь `references/source-map.md`, официальный tikz.dev и CTAN.
4. Возьми подходящий рабочий пример из `examples/`, перепроектируй под **свои** данные и формальный смысл.
5. Скомпилируй и открой PDF/PNG. Не завершай только при `exit code 0`.
6. Внедри иллюстрацию в рукопись с `\caption`/`\label`/`\ref` и укажи provenance.

## Требования

- XeLaTeX и LuaLaTeX (TeX Live или MiKTeX); пакеты `pgf`, `pgfplots`, `forest`, `standalone`, `tikz-cd`, `circuitikz`.
- Шрифт PT Sans, DejaVu Sans либо Arial (один должен присутствовать; fallback автоматический).
- Python 3.10+; для проверочного рендера `pymupdf` и `pillow` **или** `pillow` и утилита `pdftoppm`.

```bash
python -m pip install pymupdf pillow
python scripts/build_examples.py --jobs 3
```

В Windows PowerShell, запуск из распакованной папки:

```powershell
py -m pip install pymupdf pillow
py scripts\build_examples.py --jobs 3
```

`build/report.json` — результаты QA, `build/gallery.pdf` — все 15 рисунков по страницам, `build/previews/` — растровые превью.

## Структура

```text
SKILL.md                    Агентная инструкция, требования, выбор пакетов
README.md                   Установка, структура, тесты
references/source-map.md    Пакеты CTAN, документация, TeX.SE, старые PDF
references/techniques.md    Краткий технический справочник паттернов
references/visual-design.md Семантика цвета, плотность и редакционная графика
references/qa.md            Проверка компиляции, научная и визуальная QA
examples/*.tex             15 самостоятельных демонстрационных рисунков
examples/assets/*.csv      Исключительно синтетические данные
assets/synthetic_card.png  Сгенерированный демонстрационный макет (НЕ игровая карта)
templates/                 Базовый стиль и паспорт фигуры
scripts/build_examples.py  Воспроизводимая локальная компиляция
build/                     PDF, PNG, logs, JSON после сборки
MANIFEST.sha256            SHA256 всех файлов поставки
```

## Статус внешних материалов

Прочитаны и проверены разделы tikz.dev, метаданные пакетов CTAN, ряд публикаций TeX.StackExchange. Приведённый в исходной постановке мануал BU — архивная версия **1.18 (2007)**. Ресурс AMS/Brown добавлен: из индексированной аннотации проверены автор, дата и темы четырёх проектов. По прямому адресу сервер отвечал **403**, поэтому полный текст PDF и страницы не проверены (не следует цитировать по выдуманным страницам).

**Данные в примерах синтетические** — не путать с результатами Blue Moon, исследований карт или измерений.
