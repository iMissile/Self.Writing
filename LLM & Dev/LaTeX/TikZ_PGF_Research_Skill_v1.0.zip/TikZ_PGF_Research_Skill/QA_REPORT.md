# QA итог компиляции 15 примеров

Всего: **15**, успешных: **15**, `all_ok=true`.

Компиляторы: XeLaTeX (14), LuaLaTeX (1). PDF и PNG получены для всех примеров; проверено, что PDF одностраничные и превью не пустые.

| Фигура | Engine | PDF, pt | Результат |
|---|---|---:|---|
| `01_state_machine` | xelatex | 373.9 × 159.6 | PASS |
| `02_hidden_states` | xelatex | 268.2 × 224.8 | PASS |
| `03_game_tree` | xelatex | 411.6 × 176.9 | PASS |
| `04_pipeline_dag` | xelatex | 438.5 × 142.7 | PASS |
| `05_uncertainty_plot` | xelatex | 385.7 × 208.1 | PASS |
| `06_surface` | xelatex | 355.5 × 232.8 | PASS |
| `07_geometry` | xelatex | 241.3 × 187.7 | PASS |
| `08_image_roi` | xelatex | 385.9 × 277.8 | PASS |
| `09_matrix` | xelatex | 306.1 × 197.2 | PASS |
| `10_commutative` | xelatex | 101.1 × 86.5 | PASS |
| `11_timeline` | xelatex | 383.8 × 82.5 | PASS |
| `12_composite` | xelatex | 303.4 × 170.7 | PASS |
| `13_graphdrawing_lua` | lualatex | 110.9 × 215.8 | PASS |
| `14_circuit` | xelatex | 193.9 × 127.7 | PASS |
| `15_bayes_update` | xelatex | 432.2 × 125.5 | PASS |

Проверка **математической содержательности**: иллюстрации представляют учебные/концептуальные схемы; PGFPlots — исключительно синтетические входные значения. Компиляция не доказывает истинность исследовательских данных.

Особенности: запрещён `shell-escape`; граф автоматической раскладки требует LuaLaTeX. На локальной TeX Live возможны предупреждения о выключенном shell escape — они не являются ошибкой компиляции.

Превью: `build/contact_sheet.png`; сборник: `build/gallery.pdf`; машинный отчет: `build/report.json`.
