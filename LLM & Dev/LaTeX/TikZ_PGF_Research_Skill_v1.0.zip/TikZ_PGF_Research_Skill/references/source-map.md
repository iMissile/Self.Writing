# Карта источников: PGF/TikZ, CTAN, TeX Stack Exchange

**Проверено:** 2026-10-21. **Принцип:** источник лицензирует утверждение ровно о той версии, документе и способе применения, которые он покрывает. Ссылки ниже — переходы к первоисточникам, а не зеркала скачанных текстов.

## Приоритет доказательств

| Класс | Источник | Для чего пригоден | Ограничения |
|---|---|---|---|
| A1 | Официальное руководство PGF/TikZ (tikz.dev), документация пакетов CTAN | определения синтаксиса, свойства библиотеки, условия сборки | сверять с реально установленной версией |
| A2 | исходный код, release notes, issue tracker официального репозитория | баги, несовместимости, внутренние ограничения | исходники меняются; ссылаться на tag/commit |
| B | TeX.SE с воспроизводимым MWE, проверенные решения | практические приёмы, диагностика | иногда устаревшие ответы, зависимость от окружения |
| C | учебники/пособия, старые мануалы | педагогические объяснения и основа | многие keys/library изменились |
| D | некомпилируемые фрагменты блогов/AI-ответов | идеи | не доказательство корректности |

## Пользовательские базовые источники

1. **Официальная живая документация** — <https://tikz.dev/>. Главы:
   - [Design Principles](https://tikz.dev/tikz-design): язык ключей, path, node, transformation;
   - [Tutorial](https://tikz.dev/tutorial): от координат к пересечениям, clipping, transformations, pics;
   - [Coordinates](https://tikz.dev/tikz-coordinates): ортогональные и вычисляемые координаты, interpolation;
   - [Calc library](https://tikz.dev/library-calc): операции над точками;
   - [Arrows](https://tikz.dev/library-arrows): современный выбор наконечников;
   - [Patterns](https://tikz.dev/library-patterns): hatch и custom-patterns;
   - [3D](https://tikz.dev/library-3d): произвольные плоскости;
   - [Automata](https://tikz.dev/library-automata): состояния и переходы;
   - [Petri nets](https://tikz.dev/library-petri): места, переходы, токены;
   - [Graph drawing](https://tikz.dev/gd-overview): layout с Lua;
   - [Externalization](https://tikz.dev/library-external): ускорение и повторное использование (требования/безопасность);
   - [PGFPlots manual](https://tikz.dev/pgfplots/): физические/статистические графики, data visualization.
2. **PGF/TikZ PDF (архив BU)** — <https://www.bu.edu/math/files/2013/08/tikzpgfmanual.pdf>. Веб-проверкой подтверждена титульная страница: **версия 1.18, 12.06.2007**, 405 страниц. Полезен как исторический учебник по структуре языка; **не** считать актуальным справочником. Сканирована веб-просмотром титульная страница/оглавление; полный текст не копировать.
3. **Сборник tutorials от AMS/Brown** — <https://www.ams.org/arc/resources/pdfs/tikz_tutorials_all-brown.pdf>. Прямая веб-загрузка на момент проверки отвечает `403 Forbidden`. Однако поисковый индекс показывает библиографию: **Jennifer Brown, California State University Channel Islands, 19.04.2024**, «TikZ tutorials», и четыре учебных проекта: (1) парабола и пути/цвета, (2) двудольный граф и nodes, (3) диаграмма расширений полей с LuaLaTeX graphdrawing, (4) наклонная плоскость с размещением/поворотом изображения и `arrows.meta`. Это **оглавление по индексированной аннотации**, а не результат чтения всего PDF; номера страниц и конкретный код непроверены.
4. **TeX–LaTeX Stack Exchange** — <https://tex.stackexchange.com/>. Это корпус MWE, ошибок и production-решений; не замена ручной компиляции и не источник закона/математики.
5. **CTAN** — <https://ctan.org/>. Каталог пакетов, версий, зависимостей, официальных мануалов, истории обновлений и лицензий.

## CTAN: пакеты, назначение, версионирование

Версии/данные ниже зафиксированы по CTAN в дату просмотра и **не** означают, что эти версии уже установлены в локальном TeX Live.

| Пакет | CTAN | Версия по CTAN / назначение |
|---|---|---|
| PGF | https://ctan.org/pkg/pgf | 3.1.12; основной low/high-level фреймворк, TikZ frontend |
| PGFPlots | https://ctan.org/pkg/pgfplots | 1.18.3; графики 2D/3D, оси, данные |
| pgfplotstable | https://ctan.org/pkg/pgfplotstable | 1.18.3; загрузка/форматирование таблиц |
| Forest | https://ctan.org/pkg/forest | 2.1.5; плотные иерархические деревья, собственная externalization |
| istgame | https://ctan.org/pkg/istgame | игровые деревья, стратегии/ходы |
| tikz-cd | https://ctan.org/pkg/tikz-cd | 1.0; коммутативные диаграммы |
| tkz-euclide | https://ctan.org/pkg/tkz-euclide | 5.14c (16.10.2026); геометрия, активно обновляется |
| tikz-3dplot | https://ctan.org/pkg/tikz-3dplot | 3D координатные рамки, вращение/трансляция |
| nicematrix | https://ctan.org/pkg/nicematrix | 7.12 (07.10.2026); матрицы, подсветка блоков через PGF nodes |
| CircuiTikZ | https://ctan.org/pkg/circuitikz | схемотехника, множество поддерживаемых элементов |
| standalone | https://ctan.org/pkg/standalone | класс/пакет для отдельных рисунков и интеграции |
| tikzmark | https://ctan.org/pkg/tikzmark | 1.16 (31.05.2026); координаты прямо в тексте |
| pgfgantt | https://ctan.org/pkg/pgfgantt | 5.0a (19.06.2024); диаграммы Ганта |
| tcolorbox | https://ctan.org/pkg/tcolorbox | 6.10.0 (28.05.2026); theorem/code boxes, не основной рисовальный язык |
| chemfig | https://ctan.org/pkg/chemfig | 1.82 (19.09.2026); химическая нотация |
| quantikz | https://ctan.org/pkg/quantikz | 1.0.1; квантовые схемы (может требовать quantikz2 для нового API) |
| tikz-feynman | https://ctan.org/pkg/tikz-feynman | 1.1.0; диаграммы Фейнмана; автоматический layout через LuaTeX |

**Общие правила выбора:** не загружать пятнадцать пакетов «на всякий случай»; выбирать по предметной модели. CTAN сообщает о version, но не гарантирует одинаковую поддержку на всех TeX Live/MiKTeX инсталляциях. Для свежего `tkz-euclide` следить за релизом — API развивается.

### Проверка установленной системы

```bash
kpsewhich tikz.sty
kpsewhich pgfplots.sty
kpsewhich forest.sty
kpsewhich tikz-cd.sty
kpsewhich nicematrix.sty
xelatex --version
lualatex --version
texdoc -l pgf
```

В LuaLaTeX graphdrawing проверять `\usetikzlibrary{graphdrawing}` и `\usegdlibrary{...}` именно компиляцией.

## TeX.StackExchange — адресный набор решений

Список основан на реально открытых страницах вопросов; их **не копировать дословно**. Новейшие комментарии и ответы перепроверять, приведённые там приемы модифицировать под свой MWE.

- **Масштабирование рисунка:** <https://tex.stackexchange.com/questions/4338/correctly-scaling-a-tikzpicture>. Диагностировать различие `scale` и масштабирования текста; обычно решать размером фигуры и шрифтом, а не «магическим коэффициентом».
- **Использование styles:** <https://tex.stackexchange.com/questions/52372/should-tikzset-or-tikzstyle-be-used-to-define-tikz-styles>. Предпочесть `\tikzset{my style/.style=...}` вместо старого `\tikzstyle`, демонстрировать namespaced style registry.
- **Аннотации изображений:** <https://tex.stackexchange.com/questions/9559/drawing-on-an-image-with-tikz>. Узел с `includegraphics`, overlay и нормализованная система координат; обязательно обосновать базис и crop.
- **Индекс TikZ libraries:** <https://tex.stackexchange.com/questions/42611/list-of-available-tikz-libraries-with-a-short-introduction>. Полезный community index, но не полный паспорт актуальной версии.
- **Регулировка размеров стрелок:** <https://tex.stackexchange.com/questions/5461/is-it-possible-to-change-the-size-of-an-arrowhead-in-tikz-pgf>. Искать современный `arrows.meta` и проверять различия старых/nеw keys.
- **Размер текста и всей фигуры:** <https://tex.stackexchange.com/questions/26846/how-to-scale-a-tikzpicture-including-texts>. `transform shape` и более предсказуемые стратегии.
- **Разрыв строк в node:** <https://tex.stackexchange.com/questions/123671/manual-automatic-line-breaks-and-text-alignment-in-tikz-nodes>. `align`, `text width`, anchors, inner sep.

### Поисковые запросы

Использовать конкретную библиотеку и ошибку, например:

- `site:tex.stackexchange.com/questions tikz calc interpolation coordinate difference`
- `site:tex.stackexchange.com/questions tikz externalize xelatex fontspec`
- `site:tex.stackexchange.com/questions pgfplots groupplot legend outside`
- `site:tex.stackexchange.com/questions tikz picture bounding box overlay`
- `site:tex.stackexchange.com/questions pgfplots surface too slow`
- `site:tex.stackexchange.com/questions tikz standalone border includegraphics normalized coordinates`
- `site:tex.stackexchange.com/questions tikz lualatex graphdrawing unknown algorithm`

**Протокол извлечения из ответа:** зафиксировать URL, дату ответа, версию TeX в его примере (если есть), минимальный код, то, какие части исправили, локальный test status. Не принимать community vote за математическое доказательство. Сохранять ссылки и атрибуцию в комментарии, если решение существенно опирается на конкретный ответ.

## Как изучать библиотеку научно, а не как gallery украшений

1. Выяснить формальные сущности: что пакет считает узлом, path, dimension, layer, data row, variable.
2. Установить границы абстракции: auto-layout не «знает» научного смысла вершин; PGFPlots не гарантирует корректность численных данных.
3. Определить вход/выход и типы данных; привязать к документу provenance.
4. Найти 2–3 MWE: базовый, содержательный, граничный (long labels/logs/many nodes).
5. Скомпилировать всеми заявленными движками (если поддержка обещана); зафиксировать warning/error.
6. Проверить масштаб, цвета, метки, кириллицу, ссылки и PDF bounding box.
7. Сохранить локальный компилируемый recipe и короткое описание, чем он лучше самодельной реализации.

## Лицензии и этика использования

Не зеркалировать весь TikZ manual/сборники ответов или изображения без необходимости. Допустимы **свои** примеры по мотивам документации с гиперссылками и атрибуцией идей. Упомянутые пакеты имеют разные лицензии (например, PGF многолицензирован, `tikz-cd` под LPPL, `quantikz` CC BY 4.0); проверять актуальный CTAN license перед дистрибуцией *чужих* кодовых фрагментов. В этом комплекте примеры созданы самостоятельно, внешние иллюстрации не включены.

## План дальнейшего углубления по желанию

1. Graphdrawing algorithms и детерминированный layout больших графов.
2. PGFPlots: uncertainty/error bars, groupplots, surface/raster, pgfplots table data.
3. Нормализованные ROI и аннотация source-verified карт.
4. Раздельный build с XeLaTeX main + LuaLaTeX figures, кэширования и хэширования.
5. Benchmark вёрстки и визуальной регрессии (PDF-to-image diff).
