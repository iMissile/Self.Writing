# TikZ/PGF — каталог продвинутых техник (короткие рецепты)

**Примечание:** это *рецепты/фрагменты*, не всегда самостоятельные документы. Полные самостоятельные примеры — `examples/`.

## 1. Математика координат

- Декартовы `(x,y)`, физические `(2cm,3mm)`, полярные `(45:2.7cm)`.
- Относительные `+(1,0)` считают от текущей точки; `++(1,0)` дополнительно обновляет текущую точку для следующих сегментов path.
- Ортогональные `A -| B` и `A |- B` задают порядок горизонтального/вертикального сегментов.
- В библиотеке `calc` **линейная интерполяция** `($(A)!t!(B)$)` соответствует `A+t(B-A)`, а `($(A)!t!90:(B)$)` построит точку по повернутому вектору (проверить конкретную задачу по manual).
- Координаты из nodes: `(node.east)`, `(node.south west)`; пересечения `name intersections` и `intersection of A--B and C--D`.
- Требуется размерность: фиксированные координаты фигуры **не означают** физические метры без пояснения масштаба.

```tex
\usetikzlibrary{calc}
\coordinate (A) at (0,0);
\coordinate (B) at (4,2);
\coordinate (M) at ($(A)!0.5!(B)$);
\draw (A) -- (B);
\fill (M) circle (1.2pt);
```

## 2. Node position и anchors

`\usetikzlibrary{positioning}` позволяет:

```tex
\node[draw] (input) {Input};
\node[draw,right=12mm of input,anchor=west] (parser) {Parser};
\draw[-{Latex[length=2mm]}] (input.east) -- (parser.west);
```

Опцию `anchor=west` при `right=of` назначать осторожно, если без неё достаточно. Чаще всего пригодится `right=12mm of input`.

## 3. Bezier и маршруты ребер

```tex
\draw[-Latex] (a) to[out=35,in=145] node[above] {$p$} (b);
\draw[dashed] (a) .. controls +(1.2,0.8) and +(-0.7,-1) .. (b);
```

В отличие от `--` кривая не задевает промежуточный узел. Не превращать spaghetti graph в поток кривых без смысловой организации.

## 4. Матрицы и локальные node coordinates

```tex
\usetikzlibrary{matrix}
\matrix (m) [matrix of nodes,nodes={draw,minimum width=8mm},row sep=-\pgflinewidth,column sep=-\pgflinewidth] {
  1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \\ };
\draw[red,rounded corners] (m-1-1.north west) rectangle (m-2-2.south east);
```

Для настоящих математических матриц с blocks предпочесть `nicematrix`: он уже делает PGF anchors под cells и согласует математический набор.

## 5. Фоновые области и слои

```tex
\usetikzlibrary{backgrounds,fit}
\begin{scope}[on background layer]
  \node[fill=blue!5,draw=blue!50,rounded corners,
        fit=(a)(b),inner sep=6pt] {};
\end{scope}
```

Для произвольных слоев: `\pgfdeclarelayer{back}` и `\pgfsetlayers{back,main}` **до** `tikzpicture`, затем `pgfonlayer`.

## 6. Переменные и циклы

```tex
\foreach \x in {0,...,5}{\draw[gray!30] (\x,0)--(\x,3);}
```

Присвоенные `\pgfmathsetmacro` — числовые выражения PGF (не arbitrary Python); для больших расчетов готовить CSV с тестами/происхождением.

## 7. Pic symbols

```tex
\tikzset{pics/mark/.style={code={\fill[blue] (0,0) circle (1pt);}}}
\path (A) pic {mark} (B) pic {mark};
```

Один семантический символ — одно определение `pics`. Не повторять тела команд в разных исходниках.

## 8. Zoom insets / spy

`\usetikzlibrary{spy}`. Применять для важных маленьких деталей карты, пиксельного растра, обозначения. Помнить про performance и области clipping; изображение не должен быть изменен при рендере.

## 9. Фото и нормализованные координаты

Обычно ставят `\node[anchor=south west,inner sep=0] (img) at (0,0){\includegraphics[width=...]{file}};` и scope `[x={(img.south east)},y={(img.north west)}]` при условии, что картинка начинается в `(0,0)` и масштаб корректен. Затем `\draw (0.1,0.15) rectangle (0.9,0.7);`. Регистрируй все transforms если был crop.

## 10. Градиенты и shading

- Стилизованный gradient допустим в художественной/концептуальной панели, не означает числовое поле без legend.
- `\shade[left color=white,right color=blue!40] (0,0) rectangle (4,1)`.
- Для числового поля используй `PGFPlots`: это честнее, чем картинка с градиентом от руки.
- Нормаль к эквиуровням и направление градиента должны задаваться математически, а не на глаз.

## 11. Слои, неопределенность, штрафы

- Наблюденный объект: жирная сплошная граница.
- Допустимое, но не наблюдаемое: штриховая фиолетовая граница.
- Запрещённое: красная рамка + крест или hatch.
- Отклонённая гипотеза: тонкая зачёркнутая панель с подписью о причине отказа, не удалять контекст.

## 12. Вероятности/информационные множества

Определить:

\[b_t(s)=P(s_t=s\mid o_{1:t},a_{1:t-1}),\qquad
  b_{t+1}(s')\propto P(o_{t+1}\mid s')\sum_sP(s'\mid s,a_t)b_t(s).\]

Для рисунка: истинное состояние `s` — один элемент пространства; belief `b` — распределение по возможным `s`. Группировки состояния по равным observation — *не* вероятности. Не помещать проценты, когда их нет.

## 13. Граф из существующего JSON/CSV

Для 100–10 000 связей не печатать тысячи ручных узлов в исходнике. Генерировать `.tex` из schema/CSV с стабильными ID; отдельно хранить layout/fixed coordinates и отмечать seed. Графическая структура должна отражать модель, не самочинно выкидывать ребра «чтобы стало красиво».

## 14. Graphdrawing (Lua)

```tex
% Этот фрагмент предназначен для LuaLaTeX.
\usetikzlibrary{graphs,graphdrawing}
\usegdlibrary{layered}
\begin{tikzpicture}
\graph[layered layout]{ a -> {b,c}; b -> d; c -> d; };
\end{tikzpicture}
```

Стабильность layout проверять воспроизведением. `\usegdlibrary` не поддерживается XeLaTeX как аналог Lua.

## 15. Axis PGFPlots

```tex
\pgfplotsset{compat=1.18}
\begin{axis}[width=9cm, xlabel={$t$, s}, ylabel={$x$, mm},grid=major]
  \addplot[blue,thick] table[x=t,y=x,col sep=comma]{data.csv};
\end{axis}
```

**Не путать** `axis`, PGF coordinate system и `tikzpicture`: относительное преобразование координат часто применяется к не тем значениям, когда axes вложены без плана.

## 16. Error bands и Monte Carlo

Для interval `lower <= mean <= upper` каждую строку проверять вне TeX. В PGFPlots можно рисовать lower/upper и полупрозрачную закрашенную область через `fillbetween`. Если это доверительный интервал — на графике и в caption указать метод, например Wilson/bootstrap/normal; если просто диапазон — не называть CI.

## 17. 3D и честность проекций

PGFPlots `\addplot3[surf] ...` визуализирует функцию, но не гарантирует отсутствие интерполяционных артефактов. Для проекций геометрии `canvas is xy plane at z=...` и `xyz` полезны, но сложные поверхности лучше precompute. Проверять порядок граней, hidden line и толщины.

## 18. Раскладка многофигурных композиций

`subcaption` + локальные самостоятельные PDF/TEX, общий style registry, согласованная система осей. Если 4 панели в одну колонку дают шрифт ниже порога, разместить их в двух строках или в полноширинном floating figure.

## 19. Условные образы и честность данных

При отсутствии data series рисовать схему с подписью `схематично`, для обучающих plots писать `synthetic.csv` или конструировать явную аналитическую формулу. Ни одного численного результата «примерно как было в игре» без engine log и правил отбора.

## 20. Accessibility и grayscale

Любой красный/зеленый contrast нужно дублировать dashed/solid, shape или текстовой меткой. Проверять контраст не только насыщенностью, но и яркостью; на прозрачных заливках текста должно хватать воздуха.

## 21. Секреты надёжности TeX

- `\tikzset` вместо старого `\tikzstyle`;
- `arrows.meta` с явными `Latex[length=...]`;
- `\pgfplotsset{compat=<tested>}` вместо `newest`;
- `fontspec` + доступная кириллическая гарнитура при Xe/Lua;
- в `standalone` убирать ненужные packages и margins;
- `remember picture,overlay` и cross-page marks требуют 2 прохода;
- `\tikzexternalize` и external shell scripts — только контролируемые, доверенные исходники;
- внимательно изучать `Undefined control sequence`, warnings и bbox.

## 22. Дизайн по принципу доказательства

Не «рисовать красивую схему»: выбрать набор утверждений и для каждого указать, какой визуальный элемент его свидетельствует. В идеале уже по caption и двум-трём выделенным элементам читатель понимает ход рассуждения. Исторические/научные источники должны объяснять смысл, TikZ — выразить его структурно.
