from pathlib import Path
from PIL import Image, ImageDraw, ImageOps
import fitz
import math
import sys

pdf_path = Path(sys.argv[1])
out = Path(sys.argv[2] if len(sys.argv) > 2 else "qa")
out.mkdir(parents=True, exist_ok=True)

columns = 4
thumb_width = 360
label_height = 34
pages_per_sheet = 24
preview_zoom = 0.8  # только для контактного листа

with fitz.open(pdf_path) as doc:
    for start in range(0, len(doc), pages_per_sheet):
        end = min(start + pages_per_sheet, len(doc))
        rows = math.ceil((end - start) / columns)
        th = 545
        sheet = Image.new("RGB", (columns * thumb_width, rows * (th + label_height)), "#eeeeee")
        for page_index in range(start, end):
            p = doc[page_index]
            pix = p.get_pixmap(matrix=fitz.Matrix(preview_zoom, preview_zoom), alpha=False)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            img.thumbnail((thumb_width - 18, th - 10), Image.Resampling.LANCZOS)
            tile = Image.new("RGB", (thumb_width - 4, th + label_height - 4), "#f5f5f5")
            left = (tile.width - img.width) // 2
            tile.paste(img, (left, 0))
            ImageDraw.Draw(tile).text((8, th), f"Стр. {page_index + 1}", fill="#222222")
            k = page_index - start
            sheet.paste(tile, ((k % columns) * thumb_width, (k // columns) * (th + label_height)))
        output = out / f"contact_{start//pages_per_sheet+1:02d}.jpg"
        sheet.save(output, quality=88)
        print(output)
